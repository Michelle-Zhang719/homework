package month2.week8.day1.Question2.utils;

import com.mysql.jdbc.Driver;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * @Description 数据库连接
 * @Author MinjieZhang
 * @Date 2023-04-17 20:28
 */

public class JDBCConnection {
    private static final String url;
    private static final String username;
    private static final String password;

    static {

        // 通过读取配置文件
        Properties properties = new Properties();

        try {
            properties.load(new FileInputStream("jdbc.properties"));
        } catch (IOException e) {
            e.printStackTrace();
        }

        url = properties.getProperty("url");
        username = properties.getProperty("username");
        password = properties.getProperty("password");

    }
    public static Connection getConnection(){

        try {
            new Driver();

            Connection connection = DriverManager.getConnection(
                    url, username, password);
            return connection;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }
}
